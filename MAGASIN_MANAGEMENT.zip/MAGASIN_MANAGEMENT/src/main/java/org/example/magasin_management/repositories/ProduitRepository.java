package com.gestionmagasin.repositories;

import com.gestionmagasin.models.Produit;
import java.util.List;
import java.util.Optional;

public interface ProduitRepository {
    Optional<Produit> findById(int id);
    List<Produit> findAll();
    List<Produit> findByCategorie(int categorieId);
    List<Produit> findByNomContaining(String nom);
    void save(Produit produit);
    void update(Produit produit);
    void delete(int id);
    void updateQuantite(int produitId, int quantite);
}