package com.gestionmagasin.repositories;

import com.gestionmagasin.models.Vente;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface VenteRepository {
    void save(Vente vente);
    List<Vente> findByDate(LocalDate date);
    List<Vente> findByCaissier(int userId);
    List<Vente> findByClient(int clientId);
    Optional<Vente> findById(int id);
}