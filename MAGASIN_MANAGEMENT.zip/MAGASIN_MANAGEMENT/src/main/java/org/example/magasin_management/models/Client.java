package com.gestionmagasin.models;

public class Client {
    private int id;
    private String nom;
    private String contact;
    private String adresse;

    public Client(int id, String nom, String contact, String adresse) {
        this.id = id;
        this.nom = nom;
        this.contact = contact;
        this.adresse = adresse;
    }

    // Getters et setters...
}