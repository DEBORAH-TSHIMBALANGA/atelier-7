// AuthServiceImpl.java
package com.gestionmagasin.services;

import com.gestionmagasin.models.User;
import com.gestionmagasin.repositories.UserRepository;
import java.util.Optional;

public class AuthServiceImpl implements AuthService {
    private final UserRepository userRepository;

    public AuthServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User login(String username, String password) {
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (user.getPassword().equals(password)) { // En production, utiliser BCrypt
                return user;
            }
        }
        return null;
    }
}