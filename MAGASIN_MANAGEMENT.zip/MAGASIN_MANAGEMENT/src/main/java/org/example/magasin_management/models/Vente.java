package com.gestionmagasin.models;

import java.time.LocalDateTime;
import java.util.List;

public class Vente {
    private int id;
    private LocalDateTime dateVente;
    private User caissier;
    private Client client;
    private List<LigneVente> lignes;
    private double montantTotal;

    public Vente(int id, LocalDateTime dateVente, User caissier, Client client,
                 List<LigneVente> lignes, double montantTotal) {
        this.id = id;
        this.dateVente = dateVente;
        this.caissier = caissier;
        this.client = client;
        this.lignes = lignes;
        this.montantTotal = montantTotal;
    }

    // Getters et setters...
}