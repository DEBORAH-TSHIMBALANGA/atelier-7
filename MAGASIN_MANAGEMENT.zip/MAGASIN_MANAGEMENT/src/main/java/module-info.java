module org.example.magasin_management {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;
    requires java.sql;

    opens org.example.magasin_management to javafx.fxml;
}