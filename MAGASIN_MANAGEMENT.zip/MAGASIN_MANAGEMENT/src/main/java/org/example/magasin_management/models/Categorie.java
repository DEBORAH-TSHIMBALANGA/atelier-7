package com.gestionmagasin.models;

public class Categorie {
    private int id;
    private String nom;
    private String description;

    public Categorie(int id, String nom, String description) {
        this.id = id;
        this.nom = nom;
        this.description = description;
    }

    // Getters et setters...
}