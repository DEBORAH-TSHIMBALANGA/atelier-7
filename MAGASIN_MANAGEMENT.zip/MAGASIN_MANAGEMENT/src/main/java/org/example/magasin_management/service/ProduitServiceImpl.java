package com.gestionmagasin.services;

import com.gestionmagasin.models.Produit;
import com.gestionmagasin.repositories.ProduitRepository;
import java.util.List;

public class ProduitServiceImpl implements ProduitService {
    private final ProduitRepository produitRepository;

    public ProduitServiceImpl(ProduitRepository produitRepository) {
        this.produitRepository = produitRepository;
    }

    @Override
    public List<Produit> listerTousProduits() {
        return produitRepository.findAll();
    }

    @Override
    public List<Produit> rechercherProduits(String terme) {
        return produitRepository.findByNomContaining(terme);
    }

    @Override
    public void ajouterProduit(Produit produit) {
        produitRepository.save(produit);
    }

    @Override
    public void modifierProduit(Produit produit) {
        produitRepository.update(produit);
    }

    @Override
    public void supprimerProduit(int id) {
        produitRepository.delete(id);
    }

    @Override
    public void ajusterStock(int produitId, int quantite) {
        produitRepository.updateQuantite(produitId, quantite);
    }
}