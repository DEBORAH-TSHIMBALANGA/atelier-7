// UserRepositoryImpl.java
package com.gestionmagasin.repositories;

import com.gestionmagasin.config.DatabaseConfig;
import com.gestionmagasin.models.User;
import com.gestionmagasin.models.Role;
import java.sql.*;
import java.util.Optional;

public class UserRepositoryImpl implements com.gestionmagasin.repositories.UserRepository {
    @Override
    public Optional<User> findByUsername(String username) {
        String query = "SELECT * FROM users WHERE username = ?";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                User user = new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        Role.valueOf(rs.getString("role"))
                );
                return Optional.of(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }
}