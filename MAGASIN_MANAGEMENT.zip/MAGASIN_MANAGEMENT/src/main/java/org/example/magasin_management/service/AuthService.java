// AuthService.java
package com.gestionmagasin.services;

import com.gestionmagasin.models.User;

public interface AuthService {
    User login(String username, String password);
}