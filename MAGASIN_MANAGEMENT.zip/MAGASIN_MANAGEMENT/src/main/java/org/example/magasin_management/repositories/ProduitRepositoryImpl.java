package com.gestionmagasin.repositories;

import com.gestionmagasin.config.DatabaseConfig;
import com.gestionmagasin.models.Produit;
import com.gestionmagasin.models.Categorie;
import com.gestionmagasin.models.Fournisseur;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProduitRepositoryImpl implements ProduitRepository {
    @Override
    public Optional<Produit> findById(int id) {
        String query = "SELECT p.*, c.nom as categorie_nom, f.nom as fournisseur_nom " +
                "FROM produits p " +
                "LEFT JOIN categories c ON p.categorie_id = c.id " +
                "LEFT JOIN fournisseurs f ON p.fournisseur_id = f.id " +
                "WHERE p.id = ?";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Categorie categorie = new Categorie(
                        rs.getInt("categorie_id"),
                        rs.getString("categorie_nom"),
                        ""
                );

                Fournisseur fournisseur = new Fournisseur(
                        rs.getInt("fournisseur_id"),
                        rs.getString("fournisseur_nom"),
                        "",
                        ""
                );

                Produit produit = new Produit(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("description"),
                        rs.getDouble("prix"),
                        rs.getInt("quantite"),
                        categorie,
                        rs.getDate("date_expiration").toLocalDate(),
                        fournisseur
                );
                return Optional.of(produit);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public List<Produit> findAll() {
        List<Produit> produits = new ArrayList<>();
        String query = "SELECT p.*, c.nom as categorie_nom, f.nom as fournisseur_nom " +
                "FROM produits p " +
                "LEFT JOIN categories c ON p.categorie_id = c.id " +
                "LEFT JOIN fournisseurs f ON p.fournisseur_id = f.id";

        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Categorie categorie = new Categorie(
                        rs.getInt("categorie_id"),
                        rs.getString("categorie_nom"),
                        ""
                );

                Fournisseur fournisseur = new Fournisseur(
                        rs.getInt("fournisseur_id"),
                        rs.getString("fournisseur_nom"),
                        "",
                        ""
                );

                Produit produit = new Produit(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("description"),
                        rs.getDouble("prix"),
                        rs.getInt("quantite"),
                        categorie,
                        rs.getDate("date_expiration").toLocalDate(),
                        fournisseur
                );
                produits.add(produit);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return produits;
    }

    // Autres méthodes implémentées de la même manière...
}