// AuthController.java
package com.gestionmagasin.controllers;

import com.gestionmagasin.models.Role;
import com.gestionmagasin.models.User;
import com.gestionmagasin.services.AuthService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AuthController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    private final AuthService authService;

    public AuthController() {
        this.authService = new com.gestionmagasin.services.AuthServiceImpl(new com.gestionmagasin.repositories.UserRepositoryImpl());
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        User user = authService.login(username, password);

        if (user != null) {
            redirectToDashboard(user);
        } else {
            // Afficher message d'erreur
        }
    }

    private void redirectToDashboard(User user) {
        try {
            Stage stage = (Stage) usernameField.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader();
            Parent root;

            if (user.getRole() == Role.ADMIN) {
                loader.setLocation(getClass().getResource("/com/gestionmagasin/views/admin/dashboard.fxml"));
                root = loader.load();
                AdminDashboardController controller = loader.getController();
                controller.setUser(user);
            } else {
                loader.setLocation(getClass().getResource("/com/gestionmagasin/views/user/dashboard.fxml"));
                root = loader.load();
                UserDashboardController controller = loader.getController();
                controller.setUser(user);
            }

            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}