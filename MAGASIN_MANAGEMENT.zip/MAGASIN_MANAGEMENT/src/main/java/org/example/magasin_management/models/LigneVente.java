package com.gestionmagasin.models;

public class LigneVente {
    private Produit produit;
    private int quantite;
    private double prixUnitaire;
    private double sousTotal;

    public LigneVente(Produit produit, int quantite, double prixUnitaire) {
        this.produit = produit;
        this.quantite = quantite;
        this.prixUnitaire = prixUnitaire;
        this.sousTotal = quantite * prixUnitaire;
    }

    // Getters et setters...
}