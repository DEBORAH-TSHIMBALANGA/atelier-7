package com.gestionmagasin.models;

import java.time.LocalDate;

public class Produit {
    private int id;
    private String nom;
    private String description;
    private double prix;
    private int quantite;
    private Categorie categorie;
    private LocalDate dateExpiration;
    private Fournisseur fournisseur;

    // Constructeur, getters et setters
    public Produit(int id, String nom, String description, double prix, int quantite,
                   Categorie categorie, LocalDate dateExpiration, Fournisseur fournisseur) {
        this.id = id;
        this.nom = nom;
        this.description = description;
        this.prix = prix;
        this.quantite = quantite;
        this.categorie = categorie;
        this.dateExpiration = dateExpiration;
        this.fournisseur = fournisseur;
    }

    // Getters et setters...
}