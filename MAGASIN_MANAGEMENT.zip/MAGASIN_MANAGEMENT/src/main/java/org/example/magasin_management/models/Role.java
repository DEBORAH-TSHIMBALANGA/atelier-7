// Role.java
package com.gestionmagasin.models;

public enum Role {
    ADMIN,
    USER
}