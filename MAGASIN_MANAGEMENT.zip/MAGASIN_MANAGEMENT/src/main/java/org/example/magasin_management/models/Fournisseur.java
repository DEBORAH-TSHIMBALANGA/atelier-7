package com.gestionmagasin.models;

public class Fournisseur {
    private int id;
    private String nom;
    private String contact;
    private String adresse;

    public Fournisseur(int id, String nom, String contact, String adresse) {
        this.id = id;
        this.nom = nom;
        this.contact = contact;
        this.adresse = adresse;
    }

    // Getters et setters...
}