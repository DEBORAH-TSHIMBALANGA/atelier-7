package com.gestionmagasin.repositories;

import com.gestionmagasin.models.Categorie;
import java.util.List;
import java.util.Optional;

public interface CategorieRepository {
    Optional<Categorie> findById(int id);
    List<Categorie> findAll();
    void save(Categorie categorie);
    void update(Categorie categorie);
    void delete(int id);
}