// UserDashboardController.java
package com.gestionmagasin.controllers;

import com.gestionmagasin.models.User;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class UserDashboardController {
    @FXML private Label welcomeLabel;

    private User user;

    public void setUser(User user) {
        this.user = user;
        welcomeLabel.setText("Bienvenue: " + user.getUsername());
    }

    // Autres méthodes spécifiques à l'utilisateur...
}