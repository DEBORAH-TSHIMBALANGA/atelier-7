// UserRepository.java
package com.gestionmagasin.repositories;

import com.gestionmagasin.models.User;
import java.util.Optional;

public interface UserRepository {
    Optional<User> findByUsername(String username);
}