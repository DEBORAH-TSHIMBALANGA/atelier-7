package com.gestionmagasin.services;

import com.gestionmagasin.models.Produit;
import java.util.List;

public interface ProduitService {
    List<Produit> listerTousProduits();
    List<Produit> rechercherProduits(String terme);
    void ajouterProduit(Produit produit);
    void modifierProduit(Produit produit);
    void supprimerProduit(int id);
    void ajusterStock(int produitId, int quantite);
}